
(() => {
  const $ = id => document.getElementById(id);
  const PREFIX = 'CL1:', ITER = 200000;
  const enc = new TextEncoder(), dec = new TextDecoder();
  let currentToken = '';

  // Navbar
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.page').forEach(page => {
        page.hidden = page.id !== btn.dataset.page;
      });

      document.querySelectorAll('.nav-btn').forEach(b =>
        b.classList.toggle('active', b === btn)
      );
    };
  });

  function status(id, message, type = '') {
    $(id).textContent = message;
    $(id).className = 'status ' + type;
  }

  const toB64 = bytes =>
    btoa(Array.from(bytes, b => String.fromCharCode(b)).join(''));

  const fromB64 = str =>
    Uint8Array.from(atob(str), c => c.charCodeAt(0));

  async function getKey(pass, salt) {
    const base = await crypto.subtle.importKey(
      'raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']
    );

    return crypto.subtle.deriveKey({
      name: 'PBKDF2', salt, iterations: ITER, hash: 'SHA-256'
    }, base, { name: 'AES-GCM', length: 256 }, false,
    ['encrypt', 'decrypt']);
  }

  async function encrypt(text, pass) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await getKey(pass, salt);

    const data = new Uint8Array(await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv }, key, enc.encode(text)
    ));

    const result = new Uint8Array(28 + data.length);
    result.set(salt);
    result.set(iv, 16);
    result.set(data, 28);

    return PREFIX + toB64(result);
  }

  async function decrypt(token, pass) {
    token = token.trim();

    if (!token.startsWith(PREFIX))
      throw Error('Invalid token. CL1: required.');

    let data;
    try {
      data = fromB64(token.slice(PREFIX.length));
    } catch {
      throw Error('Invalid token format.');
    }

    if (data.length < 29) throw Error('Token is too short.');

    try {
      const key = await getKey(pass, data.slice(0, 16));
      const result = await crypto.subtle.decrypt({
        name: 'AES-GCM', iv: data.slice(16, 28)
      }, key, data.slice(28));

      return dec.decode(result);
    } catch {
      throw Error('Wrong passphrase or damaged data.');
    }
  }

  function drawQR(text) {
    const qr = qrcode(0, 'M');
    qr.addData(text);
    qr.make();

    const canvas = $('qr'), ctx = canvas.getContext('2d');
    const n = qr.getModuleCount(), scale = 8, margin = 4;
    canvas.width = canvas.height = (n + margin * 2) * scale;

    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#000';

    for (let r = 0; r < n; r++)
      for (let c = 0; c < n; c++)
        if (qr.isDark(r, c))
          ctx.fillRect((c + margin) * scale,
            (r + margin) * scale, scale, scale);
  }

  async function readQR(file) {
    if (typeof jsQR !== 'function')
      throw Error('QR reader unavailable. Paste the token instead.');

    const url = URL.createObjectURL(file);

    try {
      const img = new Image();
      img.src = url;
      await img.decode();

      const scale = Math.min(1, 1400 / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);

      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const result = jsQR(pixels.data, canvas.width, canvas.height,
        { inversionAttempts: 'attemptBoth' });

      if (!result) throw Error('QR not found. Upload a clear image.');
      return result.data;
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  // Encrypt and generate QR
  $('gen').onclick = async () => {
    const secret = $('secret').value;
    const pass = $('pass1').value;

    if (!secret.trim())
      return status('encStatus', 'Enter a secret.', 'bad');

    if (pass.length < 6)
      return status('encStatus', 'Passphrase must be 6+ characters.', 'bad');

    $('gen').disabled = true;
    status('encStatus', 'Encrypting...');

    try {
      currentToken = await encrypt(secret, pass);
      drawQR(currentToken);

      $('qr').hidden = $('token').hidden = false;
      $('token').textContent = currentToken;
      $('dl').disabled = $('copy').disabled = false;

      status('encStatus', 'QR generated successfully.', 'ok');
    } catch (e) {
      status('encStatus', 'Error: ' + e.message, 'bad');
    } finally {
      $('gen').disabled = false;
    }
  };

  // Download QR
  $('dl').onclick = () => {
    $('qr').toBlob(blob => {
      if (!blob)
        return status('encStatus', 'Download failed.', 'bad');

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'secret-qr.png';
      document.body.appendChild(a);
      a.click();
      a.remove();

      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }, 'image/png');
  };

  // Copy encrypted token
  $('copy').onclick = async () => {
    try {
      await navigator.clipboard.writeText(currentToken);
      status('encStatus', 'Token copied.', 'ok');
    } catch {
      status('encStatus', 'Clipboard unavailable. Copy token manually.', 'bad');
    }
  };

  // Decrypt from QR or token
  $('dec').onclick = async () => {
    const pass = $('pass2').value;

    if (!pass)
      return status('decStatus', 'Enter passphrase.', 'bad');

    $('dec').disabled = true;
    $('plain').hidden = true;

    try {
      let token = $('tokenIn').value.trim();
      const file = $('file').files[0];

      if (!token && file) {
        status('decStatus', 'Reading QR...');
        token = await readQR(file);
      }

      if (!token)
        throw Error('Upload a QR image or paste a token.');

      status('decStatus', 'Decrypting...');
      $('plain').textContent = await decrypt(token, pass);
      $('plain').hidden = false;

      status('decStatus', 'Decryption successful.', 'ok');
    } catch (e) {
      status('decStatus', e.message, 'bad');
    } finally {
      $('dec').disabled = false;
    }
  };
})();
